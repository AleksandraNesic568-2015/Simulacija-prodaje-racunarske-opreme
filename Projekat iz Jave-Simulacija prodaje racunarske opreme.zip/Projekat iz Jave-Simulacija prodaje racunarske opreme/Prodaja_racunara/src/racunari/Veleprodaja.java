
package racunari;

/* Klasa Veleprodaja nasledjuje klasu Racunari i sadrzi novi podatak kolicinu;
   Formirana je metoda Popust koja proverava sledece: ako je kolicina artikla veca od 30 i razlika izmedju  cene i nabavne cene
   veca od 2500, onda artikal zadovoljava uslov za popust(return 0);
   Koristeci vec definisanu metodu Ispis, definisana je nova Ispis_Veleprodaja;
 
  */
public class Veleprodaja extends Racunari {
	
	int kolicina;
	
	public Veleprodaja(String artikal,int cena, int nabavna_cena, double porez,int kategorija, int kolicina){
		super(artikal,cena,nabavna_cena,porez,kategorija);
		this.kolicina=kolicina;
		
	}
	
 
	public int Popust(){
		if (kolicina>=30 && cena-nabavna_cena>=2500)   
			return 0;
		else
			return 1;
	}

	public void Ispis_Veleprodaja(){
		this.Ispis();
		System.out.println("Kolicina ovog artikla je: " + kolicina);
	}
}
