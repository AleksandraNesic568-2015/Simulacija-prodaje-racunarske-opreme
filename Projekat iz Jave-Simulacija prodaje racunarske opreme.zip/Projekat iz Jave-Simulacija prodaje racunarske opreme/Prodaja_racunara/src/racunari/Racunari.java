
package racunari;    

/*Simulacija prodaje racunarske opreme
Klasa Racunari: u konstruktoru uneti su parametri(artikal,cena,nabavna cena,porez i kategorija;
Formirane su tri metode: Provera kategorije za koju vazi da ukoliko je hardware unosi se 1, a software 2;
Druga metoda je za Ispis koja omogucava kompletan ispis na standardni izlaz;
Treca metoda je Snizenje koja smanjuje cenu za 10% za neki artikal;
*/

public class Racunari {    

	String artikal;
	int cena;
	int nabavna_cena;
	double porez;
	int kategorija;
	
    Racunari(String artikal,int cena,int nabavna_cena,double porez,int kategorija){
			this.artikal=artikal;
			this.cena=cena;
			this.nabavna_cena=nabavna_cena;
			this.porez=porez;
			this.kategorija=kategorija;
	
	}
	
   public void Provera_Kategorija(){                                                //proverava kojoj kategoriji pripada artikal
    	if (kategorija==1) 
    		System.out.println("Artikal " + artikal + " pripada kategoriji HARDWARE.");
    	if (kategorija==2)
    		System.out.println("Artikal " + artikal + " pripada kategoriji SOFTWARE.");
    	else
    		System.out.println("Artikal ne pripada nijednoj kategoriji.");
    }
	
   
   public void Ispis(){                                                                              // ispis na standardni izlaz
	   System.out.println("Artikal je: " + artikal + " ,njegova cena je: " + cena + " ,nabavna cena je: " + 
   nabavna_cena + " ,porez je: " + porez);
   }
   
   public void Snizenje(){                                                                          //smanjuje cenu za neki artikal 10%
	   double s;
	   s=cena*0.90;                 
	   System.out.println("Artikal za koji se radi snizenje je: " + artikal + " ,njegova stara cena: " + cena + 
			   " ,a nova cena: " + s); 
   }
}

