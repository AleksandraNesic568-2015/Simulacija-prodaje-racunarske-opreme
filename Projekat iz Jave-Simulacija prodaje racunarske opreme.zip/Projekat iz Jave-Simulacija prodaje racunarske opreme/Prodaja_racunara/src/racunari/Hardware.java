package racunari;

/* Klasa Hardware nasledjuje klasu Racnunari i sadrzi nove podatke brend i sifru;
Formiran je konstruktor sa parametrima iz klase Racunari i dodati su parametri
brend i sifra;
Pomocu if naredbe realizovana je metoda Provera_sifre gde su ispravne sifre
u opsegu 1-99; 
Realizovana je i metoda Hardware_ispis koja omogucava kompletan ispis na standardni izlaz;
*/

public class Hardware extends Racunari{          
	
	String brend;
	int sifra;
	
	public Hardware(String artikal, int cena, int nabavna_cena, double porez,  String brend, int sifra){
		super(artikal,cena,nabavna_cena,porez,1);
		this.brend=brend;
		this.sifra=sifra;
				
	}
	
	public int Provera_sifre(){   //ispravne sifre da budu u opsegu 1-99 za hardware,ostale su neispravne
		if (sifra>=1 && sifra<=99)
			return 0;
		else
			return 1;
	}
	

	public void Hardware_Ispis(){
		System.out.println("Artikal: " + artikal + " ,cena: " + cena + " ,nabavna cena: " + nabavna_cena + ", porez " +
	porez + ", brend: " + brend + ", sifra: " + sifra) ;
	}
  

	
}
