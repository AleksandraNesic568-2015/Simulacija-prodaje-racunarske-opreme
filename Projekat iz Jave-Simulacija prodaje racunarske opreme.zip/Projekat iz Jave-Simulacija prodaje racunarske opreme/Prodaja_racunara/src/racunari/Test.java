package racunari;
import java.util.*;
import java.*;
import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		

		
		Racunari R1=new Racunari("Linux",15000,12850,0.08,2);
		Racunari R2=new Racunari("WindowsVista",12450,8750,0.18,2);
		Racunari R3=new Racunari("Windows7", 17000,15000,0.01,2);
		Hardware H1=new Hardware("WebCam",3450,2850,0.08,"Genius",98);
		Hardware H2 = new Hardware("Procesor" ,4000,3450,0.04,"Dell",43);
		Veleprodaja VP=new Veleprodaja("Tastatura",840,680,0.08,15,1);
		
		
	    int s;
		 s= Integer.parseInt(JOptionPane.showInputDialog("<html><font color=#FF0000><b>"
		 + "\n Izaberite \n"
		+ "1.Hardware \n 2.Software\n"));
		
		if (s==1){
			int s1= Integer.parseInt(JOptionPane.showInputDialog("<html><font color=#FF0000><b>"
					 + "\n Izaberite proizvod \n"
						+ "1.Procesor  \n 2.Tastatura\n 3.WebCam\n"));
						
		     if (s1==1){
		    	H2.Hardware_Ispis();
		    	
		     }
		
		    if(s1==2){
		    	  VP.Ispis_Veleprodaja();
		    	  if(VP.Popust()==0)                                                      // da li artikal iz VP-a zadovoljava uslov za popust
		  			System.out.println("Artikal:" +VP.artikal+ " ZADOVOLJAVA uslov za popust");
		  		else
		  			System.out.println("Artikal:" +VP.artikal+ " NE ZADOVOLJAVA uslov za popust");
		  		
		    }
		    
		    if(s1==3){
		    	H1.Hardware_Ispis();
		    	if (H1.Provera_sifre()==0)                                                  //provera ispravnosti sifre za H1
		    		System.out.println("Artikal:" +H1.artikal+ " ima ispravnu sifru");
		    	else 
		    		System.out.println("Artikal:" +H1.artikal+ " nema ispravnu sifru");
		    	
		    }
		    
		}
		
		
		
		if (s==2){
			int s2= Integer.parseInt(JOptionPane.showInputDialog("<html><font color=#FF0000><b>"
					 + "\n Izaberite softvware \n"
						+ "1.WindowsVista \n 2.Linux\n 3.Windows7\n"));
			
			if(s2==1){
				
				R2.Ispis();
				R2.Snizenje();
				}
			if(s2==2){
				R1.Ispis();
				R2.Provera_Kategorija();
			}
			
			if(s2==3){
				R3.Ispis();
			}
			
						
		}
		    
		 		

				
		
	}

}
